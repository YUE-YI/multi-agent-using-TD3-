
import matplotlib.pyplot as plt
import numpy as np
import math

# 定义 Trajectory 基类
class Trajectory:
    def __init__(self):
        pass

# 定义 LinearTrajectory 类
class LinearTrajectory(Trajectory):
    def __init__(self, start, end, position_function):
        super().__init__()
        self.start = np.array(start)
        self.end = np.array(end)
        self.position_function = position_function  # 位置随时间变化的函数
        self.current_position = self.start.copy()
        self.previous_position = self.start.copy()

    def position(self, t):
        """
        根据当前时间 t 计算点的位置
        :param t: 当前时间
        """
        # x坐标不变，使用位置函数计算 y 坐标的值
        y_value = self.position_function(t)
        # 计算当前位置
        self.current_position = np.array([self.start[0], y_value])
        return tuple(map(int, self.current_position))

    def velocity(self, dt):
        """
        根据时间步长 dt 计算速度
        :param dt: 时间步长
        """
        # 计算速度
        velocity = (self.current_position - self.previous_position) / dt
        self.previous_position = self.current_position.copy()
        return tuple(map(int, velocity))

# 定义 CircularTrajectory 类
class CircularTrajectory(Trajectory):
    def __init__(self, center, radius, angle_function):
        super().__init__()
        self.center = np.array(center)
        self.radius = radius
        self.angle_function = angle_function  # 角度随时间变化的函数
        self.current_position = np.array(center) + 0.5*math.sqrt(2) * self.radius
        self.previous_position = np.array(center) + 0.5*math.sqrt(2) * self.radius

    def position(self, t):
        """
        根据当前时间 t 计算点的位置
        :param t: 当前时间
        """
        # 计算当前角度
        angle = self.angle_function(t)
        # 计算当前位置
        x_value = self.center[0] + self.radius * np.cos(angle-0.5*math.pi)
        y_value = self.center[1] + self.radius * np.sin(angle-0.5*math.pi)
        self.current_position = np.array([x_value, y_value])
        return tuple(self.current_position)
        # return tuple(map(int, self.current_position))

    def velocity(self, dt):
        """
        根据时间步长 dt 计算速度
        :param dt: 时间步长
        """
        # 计算速度
        velocity = (self.current_position - self.previous_position) / dt
        self.previous_position = self.current_position.copy()
        return tuple(map(int, velocity))
    

def angle_function(t):
    return 2 * np.pi * t / 10  # 周期为 10 秒

# # 创建 CircularTrajectory 实例
# center = (200, 200)
# radius = 100
# trajectory = CircularTrajectory(center, radius, angle_function)

# # 生成轨迹数据
# time_steps = np.linspace(0, 10, 100)  # 从 0 到 10 秒，生成 100 个时间点，多少时间点与像素有关系（取整造成舍入误差）
# positions = []
# velocities = []

# # 在一个循环中同时计算位置和速度
# for i in range(len(time_steps)):
#     t = time_steps[i]
#     position = trajectory.position(t)
#     positions.append(position)
    
#     if i > 0:  # 从第二个时间点开始计算速度
#         dt = time_steps[i] - time_steps[i-1]
#         velocity = trajectory.velocity(dt)
#         velocities.append(velocity)

# # 由于速度计算需要两个位置，因此第一个位置没有对应的速度
# del velocities[0]
# velocities.insert(0, np.array([0, 0]))
# # 提取 x 和 y 坐标
# x_coords, y_coords = zip(*positions)
# xv_coords, yv_coords = zip(*velocities)
# # positions = [trajectory.position(t) for t in time_steps]
# # vectors = [trajectory.velocity(dt) for dt in np.diff(time_steps)]

# # 绘制轨迹
# plt.figure(figsize=(8, 8))
# plt.plot(x_coords, y_coords, label='Circular Trajectory')
# plt.plot(xv_coords, yv_coords,label='Velocity')
# # plt.quiver(x_coords[:-1], y_coords[:-1], vectors[0][0], vectors[0][1], angles='xy', scale_units='xy', scale=1, color='blue', label='Velocity')
# plt.scatter(center[0], center[1], color='red', label='Center')
# plt.title('Circular Trajectory')
# plt.xlabel('X Coordinate')
# plt.ylabel('Y Coordinate')
# plt.legend()
# plt.grid(True)
# plt.axis('equal')
# plt.show()