#python3.10;  numpy2.2.1; tensorboardX2.6.2.2
#TD3 has two action output based on PID for 2WD mobile robot
#直接输出两个动作，通过线性组合来控制左右轮的转速
import argparse
from collections import namedtuple
from itertools import count
import os, sys, random
import numpy as np
# import gym
# import gymnasium as gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Normal
from tensorboardX import SummaryWriter
import trajectory as tr
import env_rob2wd01 as envrob
import torch.nn.init as init
import matplotlib.pyplot as plt
import pandas as pd

cir=tr.CircularTrajectory(center=(0.8, 0.8), radius=0.8, angle_function=tr.angle_function)
# 生成轨迹数据, 从 0 到 10 秒，生成 100 个时间点，多少时间点与像素有关系（取整造成舍入误差）
positions = []
velocities = []
device = 'cuda' if torch.cuda.is_available() else 'cpu'
parser = argparse.ArgumentParser()

parser.add_argument('--mode', default='test', type=str) # mode = 'train' or 'test'
parser.add_argument("--env_name", default="DriveRob_2ow")  # OpenAI gym environment name， BipedalWalker-v2
# parser.add_argument("--env_name", default=DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.15, r=0.05))
# parser.add_argument("--tar_postion", default=tr.CircularTrajectory(center, radius, tr.angle_function))
parser.add_argument('--tau',  default=0.005, type=float) # target smoothing coefficient
parser.add_argument('--target_update_interval', default=1, type=int)
parser.add_argument('--iteration', default=3, type=int)

parser.add_argument('--learning_rate', default=1e-3, type=float)
parser.add_argument('--gamma', default=0.8, type=int) # discounted factor
parser.add_argument('--capacity', default=6000, type=int) # replay buffer size
parser.add_argument('--num_iteration', default=300, type=int) #  num of  games
parser.add_argument('--batch_size', default=100, type=int) # mini batch size
parser.add_argument('--seed', default=2, type=int)

# optional parameters
parser.add_argument('--num_hidden_layers', default=2, type=int)
parser.add_argument('--sample_frequency', default=5, type=int)
parser.add_argument('--activation', default='Relu', type=str)
parser.add_argument('--render', default=False, type=bool) # show UI or not
parser.add_argument('--log_interval', default=50, type=int) #
parser.add_argument('--load', default=True, type=bool) # load model
parser.add_argument('--render_interval', default=100, type=int) # after render_interval, the env.render() will work
parser.add_argument('--policy_noise', default=0.01, type=float)
parser.add_argument('--noise_clip', default=0.5, type=float)
parser.add_argument('--policy_delay', default=3, type=int)
parser.add_argument('--exploration_noise', default=0.02, type=float)
parser.add_argument('--max_episode', default=3000, type=int)
parser.add_argument('--print_log', default=1000, type=int)
args = parser.parse_args()

# Set seeds
torch.manual_seed(args.seed)
np.random.seed(args.seed)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
script_name = os.path.basename(__file__)
# env1 = envrob.Robot_Env(robot=envrob.DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.15, r=0.05),idx=1) #gym.make(args.env_name)


state_xdim, state_ydim = 3,3#env.observation_space.shape[0]
action_dim = 1#env.action_space.shape[0]
max_action = 40#float(env1.action_high[1])
max_action1 =2#初始3
min_Val = torch.tensor(1e-7).float().to(device) # min value

# directory = './exp' + script_name + args.env_name +'./'
directory = './expTD3_2MAS03.pyDriveRob_2ow./'
'''
Implementation of TD3 with pytorch 
Original paper: https://arxiv.org/abs/1802.09477
Not the author's implementation !
'''

class Replay_buffer():
    '''
    Code based on:
    https://github.com/openai/baselines/blob/master/baselines/deepq/replay_buffer.py
    Expects tuples of (state, next_state, action, reward, done)
    '''
    def __init__(self, max_size=args.capacity):
        self.storage = []
        self.max_size = max_size
        self.ptr = 0

    def push(self, data):
        if len(self.storage) == self.max_size:
            self.storage[int(self.ptr)] = data
            self.ptr = (self.ptr + 1) % self.max_size
        else:
            self.storage.append(data)

    def sample(self, batch_size):
        ind = np.random.randint(0, len(self.storage), size=batch_size)
        x, y, u, r, d = [], [], [], [], []

        for i in ind:
            X, Y, U, R, D = self.storage[i]
            x.append(np.array(X))
            y.append(np.array(Y))
            u.append(np.array(U))
            r.append(np.array(R))
            d.append(np.array(D))

        return np.array(x), np.array(y), np.array(u), np.array(r).reshape(-1, 1), np.array(d).reshape(-1, 1)


class Actor(nn.Module):
    # x与y方向的状态（heading和垂直heading方向），输出两个动作
    def __init__(self, state_xdim,state_ydim, action_dim, max_action):
        super(Actor, self).__init__()

        self.dim_x,self.dim_y = state_xdim,state_ydim
        self.fc10 = nn.Linear(state_xdim, 60,bias=False)
        self.fc20 = nn.Linear(state_ydim, 60,bias=False)
        self.fc11 = nn.Linear(60, 20)
        self.fc21 = nn.Linear(60, 20)
        self.fc12 = nn.Linear(20, action_dim)
        self.fc22 = nn.Linear(20, action_dim)
        self.max_action = max_action 

    def forward(self, state):
        #动作输出为PI参数变化量
        ax = F.relu(self.fc10(state[:,0,:]))
        ay = F.relu(self.fc20(state[:,1,:]))
        ax = F.relu(self.fc11(ax))
        ay = F.relu(self.fc21(ay))
        ax = self.fc12(ax)
        ay = self.fc22(ay)
        # wheel_x_pi = (torch.tanh(ax)) * self.max_action
        # wheel_y_pi = (torch.tanh(ay)) * self.max_action
        wheel_r = (torch.tanh(ax)+torch.tanh(ay)) * self.max_action#ax+ay#
        wheel_l = (torch.tanh(ax)-torch.tanh(ay)) * self.max_action#ax-ay#
        return torch.stack((wheel_l, wheel_r), dim=1)


class Critic(nn.Module):

    def __init__(self, state_xdim,state_ydim, action_dim):
        super(Critic, self).__init__()
        a_dim = 2
        self.fc1 = nn.Linear(state_xdim+state_ydim+ action_dim*a_dim, 40)
        self.fc2 = nn.Linear(40, 30)
        self.fc3 = nn.Linear(30, 1)

    def forward(self, state, action):
        # a1=state[1]
        # state_action = torch.cat([state[0],state[1], action[0],action[1]], 1)
        state_flat = state.view(state.size(0), -1)  # 展平为 [100, 6]
        action_flat = action.view(action.size(0), -1)  # 展平为 [100, 4]
        state_action = torch.cat([state_flat, action_flat], dim=1)  # 拼接为 [100, 10]
        q = F.relu(self.fc1(state_action))
        q = F.relu(self.fc2(q))
        q = self.fc3(q)
        return q


class TD3():
    def __init__(self, state_xdim, state_ydim, action_dim, max_action,id):

        self.actor = Actor(state_xdim, state_ydim, action_dim, max_action).to(device)
        self.actor_target = Actor(state_xdim, state_ydim, action_dim, max_action).to(device)
        self.critic_1 = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_1_target = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_2 = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_2_target = Critic(state_xdim, state_ydim, action_dim).to(device)

        self.actor_optimizer = optim.Adam(self.actor.parameters())
        self.critic_1_optimizer = optim.Adam(self.critic_1.parameters())
        self.critic_2_optimizer = optim.Adam(self.critic_2.parameters())

        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_1_target.load_state_dict(self.critic_1.state_dict())
        self.critic_2_target.load_state_dict(self.critic_2.state_dict())

        self.max_action = max_action
        self.memory = Replay_buffer(args.capacity)
        self.writer = SummaryWriter(directory)
        self.num_critic_update_iteration = 0
        self.num_actor_update_iteration = 0
        self.num_training = 0
        self.id=id

    def select_action(self, state):
        state=torch.tensor(state).float().to(device)
        state = state.unsqueeze(0) 
        awheel=self.actor(state)
        wheel_l, wheel_r = awheel[0,0,:],awheel[0,1,:]
        wheel_l_np = wheel_l.cpu().data.numpy().flatten()
        wheel_r_np = wheel_r.cpu().data.numpy().flatten()
        return [wheel_l_np, wheel_r_np]
        # return self.actor(state_xdim,state_ydim).cpu().data.numpy().flatten()

    def update(self, num_iteration):

        if self.num_training % 500 == 0:
            print("====================================")
            print("model has been trained for {} times...".format(self.num_training))
            print("====================================")
        for i in range(num_iteration):
            x, y, u, r, d = self.memory.sample(args.batch_size)
            state = torch.FloatTensor(x).to(device)
            action = torch.FloatTensor(u).to(device)
            next_state = torch.FloatTensor(y).to(device)
            done = torch.FloatTensor(d).to(device)
            reward = torch.FloatTensor(r).to(device)

            noise = torch.ones_like(action).data.normal_(0, args.policy_noise).to(device)
            noise = noise.clamp(-args.noise_clip, args.noise_clip)
            a1 = self.actor_target(next_state)
            # na = torch.cat(( self.actor_target(next_state)[0],self.actor_target(next_state)[1]),dim=1)
            next_action = (a1 + noise)
            next_action = next_action.clamp(-self.max_action, self.max_action)

            # Compute target Q-value:
            target_Q1 = self.critic_1_target(next_state, next_action)
            target_Q2 = self.critic_2_target(next_state, next_action)
            target_Q = torch.min(target_Q1, target_Q2)
            target_Q = reward + ((1 - done) * args.gamma * target_Q).detach()

            # Optimize Critic 1:
            current_Q1 = self.critic_1(state, action)
            loss_Q1 = F.mse_loss(current_Q1, target_Q)
            self.critic_1_optimizer.zero_grad()
            loss_Q1.backward()
            self.critic_1_optimizer.step()
            self.writer.add_scalar('Loss/Q1_loss', loss_Q1, global_step=self.num_critic_update_iteration)

            # Optimize Critic 2:
            current_Q2 = self.critic_2(state, action)
            loss_Q2 = F.mse_loss(current_Q2, target_Q)
            self.critic_2_optimizer.zero_grad()
            loss_Q2.backward()
            self.critic_2_optimizer.step()
            self.writer.add_scalar('Loss/Q2_loss', loss_Q2, global_step=self.num_critic_update_iteration)
            # Delayed policy updates:
            if i % args.policy_delay == 0:
                # Compute actor loss:
                actor_loss = - self.critic_1(state, self.actor(state)).mean()

                # Optimize the actor
                self.actor_optimizer.zero_grad()
                actor_loss.backward()
                self.actor_optimizer.step()
                self.writer.add_scalar('Loss/actor_loss', actor_loss, global_step=self.num_actor_update_iteration)
                for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
                    target_param.data.copy_(((1- args.tau) * target_param.data) + args.tau * param.data)

                for param, target_param in zip(self.critic_1.parameters(), self.critic_1_target.parameters()):
                    target_param.data.copy_(((1 - args.tau) * target_param.data) + args.tau * param.data)

                for param, target_param in zip(self.critic_2.parameters(), self.critic_2_target.parameters()):
                    target_param.data.copy_(((1 - args.tau) * target_param.data) + args.tau * param.data)

                self.num_actor_update_iteration += 1
        self.num_critic_update_iteration += 1
        self.num_training += 1

    def save(self):
        torch.save(self.actor.state_dict(), directory+'actor041{}.pth'.format(self.id))
        torch.save(self.actor_target.state_dict(), directory+'actor_target{}.pth'.format(self.id))
        torch.save(self.critic_1.state_dict(), directory+'critic_1{}.pth'.format(self.id))
        torch.save(self.critic_1_target.state_dict(), directory+'critic_1_target{}.pth'.format(self.id)) 
        torch.save(self.critic_2.state_dict(), directory+'critic_2{}.pth'.format(self.id))
        torch.save(self.critic_2_target.state_dict(), directory+'critic_2_target{}.pth'.format(self.id))
        print("====================================")
        print("Model has been saved...")
        print("====================================")

    def load(self):
        if self.id==5:
            self.actor.load_state_dict(torch.load(directory + 'actor041{}.pth'.format(self.id), weights_only=True))
        else:
            self.actor.load_state_dict(torch.load(directory + 'actor041{}.pth'.format(self.id), weights_only=True))
            self.actor_target.load_state_dict(torch.load(directory + 'actor_target{}.pth'.format(self.id), weights_only=True))
            self.critic_1.load_state_dict(torch.load(directory + 'critic_1{}.pth'.format(self.id), weights_only=True))
            self.critic_1_target.load_state_dict(torch.load(directory + 'critic_1_target{}.pth'.format(self.id), weights_only=True))
            self.critic_2.load_state_dict(torch.load(directory + 'critic_2{}.pth'.format(self.id), weights_only=True))
            self.critic_2_target.load_state_dict(torch.load(directory + 'critic_2_target{}.pth'.format(self.id), weights_only=True))
        # print("====================================")
        # print("model has been loaded...")
        # print("====================================")


def main():
    agentlist_TD,position_list,tposelist,errorlist=[],[],[0,0,0,0],[]
    
    for _ in range(5):
        if _ !=4:
            agentlist_TD.append(TD3(state_xdim+2, state_ydim+2, action_dim, max_action1,_+1))
        else:   
            agentlist_TD.append(TD3(state_xdim, state_ydim, action_dim, max_action,_+1))
    states,rewards,dones,states1 =[0,0,0,0],[0,0,0,0], [False, False, False, False],[0,0,0,0]
    actionmulti=[]
    nebors_position= np.array([[0,0], [-0.5,-0.2], [0.1,0.3], [0.25,-0.25]])
    init_states = np.array([[0,0,0], [-0.5,-0.2,0], [0.1,0.3,0], [0.25,-0.25,1.0]])
    neb_theta,tra_theta = np.array([0,0,0,1.0]),0#init_states的每一个最后一位元素值
    agent_envs = [envrob.Robot_Env(robot=envrob.DifferentialDriveRobot(x=state[0], y=state[1], theta=state[2]),
        idx=i + 1) for i, state in enumerate(init_states)]
    path_x = [[] for _ in range(4)]  # 假设有4个agent
    path_y = [[] for _ in range(4)] 
    actionlist = [np.array([0,0]),np.array([0,0]),np.array([0,0]),np.array([0,0])]
    df = pd.read_csv("PID_error01.csv")
    df_np = df.to_numpy()
    df_path = pd.read_csv("robot_path_pid.csv")
    path_xPID = df_path['x'].values
    path_yPID = df_path['y'].values
    act=np.array([0,0])
    if args.mode == 'test':
        for j in range(5):
            agentlist_TD[j].load()
        action = np.array([0, 0])  # 初始化 action
        for i in range(1):
            ep_r = [0,0,0,0]
            for j, env in enumerate(agent_envs):
                env.reset(robot=envrob.DifferentialDriveRobot(x=init_states[j][0], y=init_states[j][1], theta=init_states[j][2]))
            for t in range(3000):
                if t<=500:
                    coop=0
                else:
                    coop = 0
                if (t % 10 == 0):
                    time_t = t * 0.01
                    position = cir.position(time_t)
                    position_last = cir.position(t*0.01-0.01)
                    position_list.append(position)
                    for j in range(4):
                        tposelist[j]=tr.tra_position(position,position_last,j)
                        agent_envs[j].positions.append(tposelist[j])
                    if t>11:
                        tra_theta = envrob.calculate_angle(agent_envs[1].positions[-2], position)
                        velocity = cir.velocity(0.1)
                        velocities.append(velocity) 
                if (t % 20 == 0) and (t!=0):  
                    error_PID = df_np[t//20 -1]
                    for j in range(4):
                        localxy = envrob.global_to_local(nebors_position,neb_theta,j)
                        agent_envs[j].local_position=localxy
                        state, reward, done, *info = agent_envs[j].step(tposelist[j] ,error_PID,act,nebors_position,neb_theta,tra_theta=None)
                        action2 = agentlist_TD[4].select_action(np.array(state))
                        state = envrob.append_columns_to_array(action2,localxy)
                        ep_r[j] += reward
                        if t<1:
                            action,ax,ay = agent_envs[i].pid_output(state)#env.calculate_pid(position) 
                        else:
                            action1 = agentlist_TD[j].select_action(np.array(state))
                            action = np.array([coop*action1[0][0]+action2[0][0],coop*action1[1][0]+action2[1][0]])

                        actionlist[j] = action
                    actionmulti.append(actionlist.copy()) 
                for j in range(4):
                    ax1,ay1 = agent_envs[j].robot_go(actionlist[j],t)
                    nebors_position[j] =   np.array([ax1,ay1])
                    neb_theta[j] = agent_envs[j].robot.theta
            for j in range(4):
                print("ep_r is \t{:0.2f}".format(ep_r[j]))
            position_list = np.array(position_list)
            x_coords, y_coords = position_list[:,0], position_list[:,1]
            for j in range(4): 
                path_x[j],path_y[j] = zip(*agent_envs[j].robot.path)
            actionmulti_flat = [[action[0][0], action[0][1], action[1][0], action[1][1], action[2][0], action[2][1], action[3][0], action[3][1]] for action in actionmulti]
            df = pd.DataFrame(actionmulti_flat, columns=['agent1_x', 'agent1_y', 'agent2_x', 'agent2_y', 'agent3_x', 'agent3_y', 'agent4_x', 'agent4_y'])
            df.to_csv("TD3_action_multi02.csv", index=False)
            envrob.plot_trajectory_and_path(x_coords, y_coords, path_x, path_y,path_xPID, path_yPID)

    elif args.mode == 'train':
        print("====================================")
        print("Collection Experience...")
        print("====================================")
        if args.load: 
            for j in range(5): 
                if j ==4:
                    agentlist_TD[j].load()
        for i in range(args.num_iteration):
            ep_r = [0,0,0,0]
            state_prelist= []
            action = np.array([0, 0])  # 初始化 action
            action1,action2 = np.array([[0], [0]]),np.array([[0], [0]])  # 初始化 action
            for j, env in enumerate(agent_envs):
                state_pre = env.reset(robot=envrob.DifferentialDriveRobot(x=init_states[j][0], y=init_states[j][1], theta=init_states[j][2]))
                state_pre = envrob.append_columns_to_array(action2,state_pre)
                state_prelist.append(state_pre)
            for t in range(3000):#30秒，间隔0.01s
                if (t % 10 == 0):
                    time_t = t * 0.01
                    position = cir.position(time_t)
                    for j in range(4):
                        agent_envs[j].positions.append(position)
                    if t>11:
                        tra_theta = envrob.calculate_angle(position,agent_envs[1].positions[-2])
                        velocity = cir.velocity(0.1)
                        velocities.append(velocity) 
                if (t % 20 == 0) and (t!=0):
                    error_PID = df_np[t//20 -1]
                    for j in range(4):
                        localxy = envrob.global_to_local(nebors_position,neb_theta,j)
                        agent_envs[j].local_position=localxy
                        state, reward, done, *info = agent_envs[j].step(position,error_PID,action,nebors_position,neb_theta,tra_theta=None)
                        action2 = agentlist_TD[4].select_action(np.array(state))
                        state = envrob.append_columns_to_array(action2,localxy)
                        ep_r[j] += reward
                        agentlist_TD[j].memory.push((state_prelist[j], state, action1, reward, np.float64(done)))
                        action1 = agentlist_TD[j].select_action(np.array(state))
                        action = np.array([action1[0][0]+action2[0][0],action1[1][0]+action2[1][0]])
                        actionlist[j] = action
                        state_prelist[j] = state
                        if i+1 % 10 == 0:
                            print('Episode {},  The memory size is {} '.format(i, len(agentlist_TD[j].memory.storage)))
                        if len(agentlist_TD[j].memory.storage) >= args.capacity-1 and t%40 == 0:
                            agentlist_TD[j].update(1)
                    
                    if (True in dones) or (t == args.max_episode -1):
                        for j in range(4):
                            agentlist_TD[j].writer.add_scalar('ep_r', ep_r[j], global_step=i)
                        if i % args.print_log == 0:
                            print("Ep_i \t{}, the ep_r is \t{:0.2f}, the step is \t{}".format(i, ep_r[j], t))
                        ep_r = [0,0,0,0]
                        break
                for j in range(4):
                    ax1,ay1 = agent_envs[j].robot_go(actionlist[j],t)
                    nebors_position[j] =   np.array([ax1,ay1])
                    neb_theta[j] = agent_envs[j].robot.theta
            for j in range(4):
                if i % args.log_interval == 0:
                    agentlist_TD[j].save()
    else:
        raise NameError("mode wrong!!!")

if __name__ == '__main__':
    main()