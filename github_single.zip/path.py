import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df1= pd.read_csv("pid_path01.csv")
df2 = pd.read_csv("TD3_1_path01.csv")
df3 = pd.read_csv("ref_path01.csv")
df21  = pd.read_csv("TD3_1_path021.csv")
df11 = pd.read_csv("pid_path011.csv")
x1 = df1['x'].tolist()
y1 = df1['y'].tolist()
x2 = df2['x'].tolist()
y2 = df2['y'].tolist()
x3 = df3['x'].tolist()
y3 = df3['y'].tolist()
x11 = df11['x'].tolist()
y11 = df11['y'].tolist()
x21 = df21['x'].tolist()
y21 = df21['y'].tolist()


figsize = (6, 6)
plt.figure(figsize=figsize)
plt.plot(x3, y3, marker='o',label='Leader',markersize=4)
plt.plot(x1, y1, marker='o',label='PID',markersize=3.5)
plt.plot(x2, y2, marker='o',label='TD3_1',markersize=3.5)
# plt.plot(x11, y11, marker='o',label='PID',markersize=3.5)
# plt.plot(x21, y21, marker='o',label='TD3_1',markersize=3.5)

ax = plt.gca()
ax.set_xlim(-0.5, 2.1)
ax.set_ylim(-0.5, 2.1)
ax.set_aspect('equal')
plt.xlabel('x (m)', fontsize=14)  # 设置X轴标签字体大小为14
plt.ylabel('y (m)', fontsize=14)  # 设置Y轴标签字体大小为14
# plt.title('Path Comparison')
plt.grid(True)
# plt.axis('equal')
plt.legend()
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.savefig('trajectory0110.png', dpi=600)
plt.show()