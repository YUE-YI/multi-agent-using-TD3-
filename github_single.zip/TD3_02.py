#python3.10; gym0.26.2 + gymnasium1.0.0; numpy2.2.1; tensorboardX2.6.2.2
#TD3 has two action output based on PID for 2WD mobile robot
#使用TD3对PID参数动态调整，自适应
import argparse
from collections import namedtuple
from itertools import count
import os, sys, random
import numpy as np
# import gym
# import gymnasium as gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Normal
from tensorboardX import SummaryWriter
import trajectory as tr
import env_rob2wd01 as envrob
import torch.nn.init as init
import matplotlib.pyplot as plt
import pandas as pd

cir=tr.CircularTrajectory(center=(0.8, 0.8), radius=0.8, angle_function=tr.angle_function)
# 生成轨迹数据, 从 0 到 10 秒，生成 100 个时间点，多少时间点与像素有关系（取整造成舍入误差）
positions = []
velocities = []
device = 'cuda' if torch.cuda.is_available() else 'cpu'
parser = argparse.ArgumentParser()

parser.add_argument('--mode', default='test', type=str) # mode = 'train' or 'test'
parser.add_argument("--env_name", default="DriveRob_2ow")  # OpenAI gym environment name， BipedalWalker-v2
# parser.add_argument("--env_name", default=DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.15, r=0.05))
# parser.add_argument("--tar_postion", default=tr.CircularTrajectory(center, radius, tr.angle_function))
parser.add_argument('--tau',  default=0.005, type=float) # target smoothing coefficient
parser.add_argument('--target_update_interval', default=1, type=int)
parser.add_argument('--iteration', default=3, type=int)

parser.add_argument('--learning_rate', default=1e-2, type=float)
parser.add_argument('--gamma', default=0.9, type=int) # discounted factor
parser.add_argument('--capacity', default=10000, type=int) # replay buffer size
parser.add_argument('--num_iteration', default=5000, type=int) #  num of  games
parser.add_argument('--batch_size', default=100, type=int) # mini batch size
parser.add_argument('--seed', default=1, type=int)

# optional parameters
parser.add_argument('--num_hidden_layers', default=2, type=int)
parser.add_argument('--sample_frequency', default=5, type=int)
parser.add_argument('--activation', default='Relu', type=str)
parser.add_argument('--render', default=False, type=bool) # show UI or not
parser.add_argument('--log_interval', default=50, type=int) #
parser.add_argument('--load', default=False, type=bool) # load model
parser.add_argument('--render_interval', default=100, type=int) # after render_interval, the env.render() will work
parser.add_argument('--policy_noise', default=0.01, type=float)
parser.add_argument('--noise_clip', default=0.5, type=float)
parser.add_argument('--policy_delay', default=4, type=int)
parser.add_argument('--exploration_noise', default=0.01, type=float)
parser.add_argument('--max_episode', default=3000, type=int)
parser.add_argument('--print_log', default=1, type=int)
args = parser.parse_args()

# Set seeds
# torch.manual_seed(args.seed)
# np.random.seed(args.seed)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
script_name = os.path.basename(__file__)
env = envrob.Robot_Env(robot=envrob.DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.05, r=0.0075)) #gym.make(args.env_name)


state_xdim, state_ydim = 3,3#env.observation_space.shape[0]
action_dim = 1#env.action_space.shape[0]
max_action = 50#float(env.action_high[1])
min_Val = torch.tensor(1e-7).float().to(device) # min value

directory = './exp' + script_name + args.env_name +'./'
'''
Implementation of TD3 with pytorch 
Original paper: https://arxiv.org/abs/1802.09477
Not the author's implementation !
'''

class Replay_buffer():
    '''
    Code based on:
    https://github.com/openai/baselines/blob/master/baselines/deepq/replay_buffer.py
    Expects tuples of (state, next_state, action, reward, done)
    '''
    def __init__(self, max_size=args.capacity):
        self.storage = []
        self.max_size = max_size
        self.ptr = 0

    def push(self, data):
        if len(self.storage) == self.max_size:
            self.storage[int(self.ptr)] = data
            self.ptr = (self.ptr + 1) % self.max_size
        else:
            self.storage.append(data)

    def sample(self, batch_size):
        ind = np.random.randint(0, len(self.storage), size=batch_size)
        x, y, u, r, d = [], [], [], [], []

        for i in ind:
            X, Y, U, R, D = self.storage[i]
            x.append(np.array(X))
            y.append(np.array(Y))
            u.append(np.array(U))
            r.append(np.array(R))
            d.append(np.array(D))

        return np.array(x), np.array(y), np.array(u), np.array(r).reshape(-1, 1), np.array(d).reshape(-1, 1)


class Actor(nn.Module):
    # x与y方向的状态（heading和垂直heading方向），输出两个动作
    def __init__(self, state_xdim, state_ydim, action_dim, max_action):
        super(Actor, self).__init__()

        self.dim_x, self.dim_y = state_xdim, state_ydim
        self.fc10 = nn.Linear(6, 2, bias=False)
        # self.fc12 = nn.Linear(4, 2, bias=False)
        self.max_action = max_action

        # 设置固定的初始权值
        self.fc10.weight = nn.Parameter(torch.tensor([
            [20, 2, 0.1, 0, 0, 0],
            # [0, 0, 0, 0, 0, 0],
            # [0, 0, 0, 0, 0, 0],
            [0, 0, 0,  8, 5, 0.05]
        ], dtype=torch.float32))  # 设置fc10的权重为固定的值

        # self.fc12.weight = nn.Parameter(torch.tensor([
        #     [1, 0, 0, 0],
        #     [0, 0, 0, 1]
        # ], dtype=torch.float32))  # 设置fc12的权重为固定的值

    def forward(self, state):
        ax = self.fc10(state)
        # ax = self.fc12(ax)
        wheel_r = ax[:,:, 0] - ax[:,:, 1]
        wheel_l = ax[:,:, 0] + ax[:,:, 1]
        # wheel_r = (torch.tanh(ax[:,:, 0]) - torch.tanh(ax[:,:, 1])) * self.max_action
        # wheel_l = (torch.tanh(ax[:,:, 0]) + torch.tanh(ax[:,:, 1])) * self.max_action
        return torch.stack((wheel_l, wheel_r), dim=1)


class Critic(nn.Module):

    def __init__(self, state_xdim,state_ydim, action_dim):
        super(Critic, self).__init__()

        self.fc1 = nn.Linear(state_xdim+state_ydim+ action_dim*2, 40)
        self.fc2 = nn.Linear(40, 30)
        self.fc3 = nn.Linear(30, 1)

    def forward(self, state, action):
        # a1=state[1]
        # state_action = torch.cat([state[0],state[1], action[0],action[1]], 1)
        state_flat = state.view(state.size(0), -1)  # 展平为 [100, 6]
        action_flat = action.view(action.size(0), -1)  # 展平为 [100, 4]
        state_action = torch.cat([state_flat, action_flat], dim=1)  # 拼接为 [100, 10]
        q = F.relu(self.fc1(state_action))
        q = F.relu(self.fc2(q))
        q = self.fc3(q)
        return q


class TD3():
    def __init__(self, state_xdim, state_ydim, action_dim, max_action):

        self.actor = Actor(state_xdim, state_ydim, action_dim, max_action).to(device)
        self.actor_target = Actor(state_xdim, state_ydim, action_dim, max_action).to(device)
        self.critic_1 = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_1_target = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_2 = Critic(state_xdim, state_ydim, action_dim).to(device)
        self.critic_2_target = Critic(state_xdim, state_ydim, action_dim).to(device)

        self.actor_optimizer = optim.Adam(self.actor.parameters())
        self.critic_1_optimizer = optim.Adam(self.critic_1.parameters())
        self.critic_2_optimizer = optim.Adam(self.critic_2.parameters())

        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_1_target.load_state_dict(self.critic_1.state_dict())
        self.critic_2_target.load_state_dict(self.critic_2.state_dict())

        self.max_action = max_action
        self.memory = Replay_buffer(args.capacity)
        self.writer = SummaryWriter(directory)
        self.num_critic_update_iteration = 0
        self.num_actor_update_iteration = 0
        self.num_training = 0

    def select_action(self, state):
        state=torch.tensor(state).float().to(device)
        # state = state.unsqueeze(0) 
        state = state.view(1,1,-1) 
        awheel=self.actor(state)
        wheel_l, wheel_r = awheel[0,0,:],awheel[0,1,:]
        wheel_l_np = wheel_l.cpu().data.numpy().flatten()
        wheel_r_np = wheel_r.cpu().data.numpy().flatten()
        return [wheel_l_np, wheel_r_np]
        # return self.actor(state_xdim,state_ydim).cpu().data.numpy().flatten()

    def update(self, num_iteration):

        if self.num_training % 500 == 0:
            print("====================================")
            print("model has been trained for {} times...".format(self.num_training))
            print("====================================")
        for i in range(num_iteration):
            x, y, u, r, d = self.memory.sample(args.batch_size)
            state = torch.FloatTensor(x).to(device)
            action = torch.FloatTensor(u).to(device)
            next_state = torch.FloatTensor(y).to(device)
            done = torch.FloatTensor(d).to(device)
            reward = torch.FloatTensor(r).to(device)

            # state = state.permute(1, 0, 2)  # 重塑为 [2, 3, 100]
            # next_state = next_state.permute(1, 0, 2)  
            # action = action.permute(1, 0, 2)
            # Select next action according to target policy:
            noise = torch.ones_like(action).data.normal_(0, args.policy_noise).to(device)
            noise = noise.clamp(-args.noise_clip, args.noise_clip)
            ns = next_state.view(next_state.size(0), -1)
            ns = next_state.view(next_state.size(0), 1, -1)
            s1 = state.view(state.size(0), -1)
            s1 = state.view(state.size(0), 1, -1)
            a1 = self.actor_target(ns )
            # na = torch.cat(( self.actor_target(next_state)[0],self.actor_target(next_state)[1]),dim=1)
            next_action = (a1 + noise)
            next_action = next_action.clamp(-self.max_action, self.max_action)

            # Compute target Q-value:
            target_Q1 = self.critic_1_target(next_state, next_action)
            target_Q2 = self.critic_2_target(next_state, next_action)
            target_Q = torch.min(target_Q1, target_Q2)
            target_Q = reward + ((1 - done) * args.gamma * target_Q).detach()

            # Optimize Critic 1:
            current_Q1 = self.critic_1(state, action)
            loss_Q1 = F.mse_loss(current_Q1, target_Q)
            self.critic_1_optimizer.zero_grad()
            loss_Q1.backward()
            self.critic_1_optimizer.step()
            self.writer.add_scalar('Loss/Q1_loss', loss_Q1, global_step=self.num_critic_update_iteration)

            # Optimize Critic 2:
            current_Q2 = self.critic_2(state, action)
            loss_Q2 = F.mse_loss(current_Q2, target_Q)
            self.critic_2_optimizer.zero_grad()
            loss_Q2.backward()
            self.critic_2_optimizer.step()
            self.writer.add_scalar('Loss/Q2_loss', loss_Q2, global_step=self.num_critic_update_iteration)
            # Delayed policy updates:
            if i % args.policy_delay == 0:
                # Compute actor loss:
                actor_loss = - self.critic_1(state, self.actor(s1)).mean()

                # Optimize the actor
                self.actor_optimizer.zero_grad()
                actor_loss.backward()
                self.actor_optimizer.step()
                self.writer.add_scalar('Loss/actor_loss', actor_loss, global_step=self.num_actor_update_iteration)
                for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
                    target_param.data.copy_(((1- args.tau) * target_param.data) + args.tau * param.data)

                for param, target_param in zip(self.critic_1.parameters(), self.critic_1_target.parameters()):
                    target_param.data.copy_(((1 - args.tau) * target_param.data) + args.tau * param.data)

                for param, target_param in zip(self.critic_2.parameters(), self.critic_2_target.parameters()):
                    target_param.data.copy_(((1 - args.tau) * target_param.data) + args.tau * param.data)

                self.num_actor_update_iteration += 1
        self.num_critic_update_iteration += 1
        self.num_training += 1

    def save(self):
        torch.save(self.actor.state_dict(), directory+'actor.pth')
        torch.save(self.actor_target.state_dict(), directory+'actor_target.pth')
        torch.save(self.critic_1.state_dict(), directory+'critic_1.pth')
        torch.save(self.critic_1_target.state_dict(), directory+'critic_1_target.pth')
        torch.save(self.critic_2.state_dict(), directory+'critic_2.pth')
        torch.save(self.critic_2_target.state_dict(), directory+'critic_2_target.pth')
        print("====================================")
        print("Model has been saved...")
        print("====================================")

    def load(self):
        self.actor.load_state_dict(torch.load(directory + 'actor.pth', weights_only=True))
        self.actor_target.load_state_dict(torch.load(directory + 'actor_target.pth', weights_only=True))
        self.critic_1.load_state_dict(torch.load(directory + 'critic_1.pth', weights_only=True))
        self.critic_1_target.load_state_dict(torch.load(directory + 'critic_1_target.pth', weights_only=True))
        self.critic_2.load_state_dict(torch.load(directory + 'critic_2.pth', weights_only=True))
        self.critic_2_target.load_state_dict(torch.load(directory + 'critic_2_target.pth', weights_only=True))
        print("====================================")
        print("model has been loaded...")
        print("====================================")


def main():
    agent = TD3(state_xdim, state_ydim, action_dim, max_action)
    ep_r,actionlist = 0,[]
    env = envrob.Robot_Env(robot=envrob.DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.05, r=0.0075))
    df = pd.read_csv("PID_error01.csv")
    df_np = df.to_numpy()
    if args.mode == 'test':
        agent.load()
        actor_state_dict = agent.actor.state_dict()
        # 打印权值
        for name, param in actor_state_dict.items():
            print(f"Layer: {name}, Shape: {param.shape}")
            print(param)
        action = np.array([0, 0])  # 初始化 action
        for i in range(1):
            state = env.reset(robot=envrob.DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.05, r=0.0075))
            for t in range(3000):
                if (t % 10 == 0):
                    time_t = t * 0.01
                    position = cir.position(time_t)
                    env.positions.append(position)
                    if t>11:
                        velocity = cir.velocity(0.1)
                        velocities.append(velocity) 
                if (t % 20 == 0) and (t!=0):  
                    error_PID = df_np[t//20 -1]
                    next_state, reward, done, *info = env.step(position,error_PID,action)
                    ep_r += reward
                    if t<3:
                        action,ax,ay = env.pid_output(next_state)#env.calculate_pid(position) #PID引导TD3训练,calculate_pid与env.step有冲突
                    else:
                        # action1,ax1,ay1 = env.pid_output(next_state)
                        action1 = agent.select_action(np.array(next_state))
                        action = np.array([action1[0][0],action1[1][0]])
                    actionlist.append(action)
                env.robot_go(action,t)
            # df = pd.DataFrame(env.error_p)
            # df.to_csv("PID_error01.csv", index=False)
            df = pd.DataFrame(actionlist)
            df.to_csv("TD3_action01TD3.csv", index=False)
            print("the ep_r is \t{:0.2f},".format(ep_r))
            x_coords, y_coords = zip(*env.positions)  
            path_x, path_y = zip(*env.robot.path)
            indices = np.arange(len(x_coords))
            cmap = plt.get_cmap('viridis')
            colors = cmap(indices / len(indices))  # 归一化索引到[0, 1]
            # plt.figure(figsize=(8, 8))
            plt.plot(x_coords, y_coords, label='Circular Trajectory')
            plt.plot(path_x, path_y, marker='o', linestyle='-', color='r')
            plt.scatter(x_coords, y_coords, c=colors, label='Circular Trajectory with Gradient')  # 使用颜色映射
            plt.legend()
            plt.grid(True)
            plt.axis('equal')
            plt.colorbar(label='Index')  # 添加颜色条以显示索引与颜色的对应关系
            plt.show()

    elif args.mode == 'train':
        print("====================================")
        print("Collection Experience...")
        print("====================================")
        if args.load: agent.load()
        for i in range(args.num_iteration):
            state_pre = env.reset(robot=envrob.DifferentialDriveRobot(x=0.0, y=0.0, theta=0.0, L=0.05, r=0.0075))
            action = np.array([[0], [0]])  # 初始化 action
            action1 = np.array([0,0])
            # state = state[0]
            for t in range(3000):#30秒，间隔0.01s
                if (t % 10 == 0):
                    time_t = t * 0.01
                    # print(t)
                    position = cir.position(time_t)
                    env.positions.append(position)
                    if t>11:
                        velocity = cir.velocity(0.1)
                        velocities.append(velocity) 
                if (t % 20 == 0) and (t!=0):
                    error_PID = df_np[t//20 -1]
                    state, reward, done, *info = env.step(position,error_PID,action)
                    ep_r += reward
                    agent.memory.push((state_pre, state, action, reward, np.float64(done)))
                    if t<3000:
                        action1,ax,ay= env.pid_output(state)
                        actionTD = agent.select_action(np.array(state))
                    else:
                        action = agent.select_action(np.array(state))
                        action1 = np.array([action[0][0],action[1][0]])
                        # action1,ax,ay = env.DPID_output(state,action) #PID引导TD3训练
                        
                    # action = np.array(action).flatten() + np.random.normal(0, args.exploration_noise, size=2)
                    state_pre = state
                    if i+1 % 10 == 0:
                        print('Episode {},  The memory size is {} '.format(i, len(agent.memory.storage)))
                    if done or t == args.max_episode -1 or ep_r<-1200:
                        agent.writer.add_scalar('ep_r', ep_r, global_step=i)
                        if i % args.print_log == 0:
                            print("Ep_i \t{}, the ep_r is \t{:0.2f}, the step t is \t{}".format(i, ep_r, t))
                        ep_r = 0
                        break
                    if len(agent.memory.storage) >= args.capacity-1:
                        agent.update(1)
                env.robot_go(action1,t)


            if i % args.log_interval == 0:
                agent.save()

    else:
        raise NameError("mode wrong!!!")

if __name__ == '__main__':
    main()