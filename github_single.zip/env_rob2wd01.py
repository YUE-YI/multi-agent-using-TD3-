import numpy as np
import random
import matplotlib.pyplot as plt
import pandas as pd
import math
import trajectory as tr
from matplotlib.animation import FuncAnimation
dt = 0.2
center = (0.8, 0.8)
radius = 0.8
cir=tr.CircularTrajectory(center, radius, tr.angle_function)
A = np.array([[0, 0, 0, 1],
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0]])
G = np.array([1, 1, 1, 1])
L= np.array([[-1, 0, 0, 1],
            [1, -1, 0, 0],
            [0, 1, -1, 0],
            [0, 0, 1, -1]])

class DifferentialDriveRobot:
    def __init__(self, x=0.0, y=0.0, theta=0.0, L=0.05, r=0.0075):
        """
        初始化机器人的状态。
        :param x: 机器人的初始x坐标 (默认为0.0)
        :param y: 机器人的初始y坐标 (默认为0.0)
        :param theta: 机器人的初始朝向角度 (默认为0.0, 单位是弧度)
        :param L: 轮距 (默认为0.05米)
        :param r: 轮子半径 (默认为0.0075米)
        """
        self.x = x
        self.y = y
        self.theta = theta
        self.L = L
        self.r = r
        self.path = [(x, y)]  # 用于记录路径的列表
        self.vx, self.vy = 0.0, 0.0  # 初始化速度为0
        self.history = []  # 用于存储历史数据的列表

    def update(self, omega_l, omega_r, dt, t):
        """
        更新机器人的状态。
        :param omega_l: 左轮角速度 (单位是弧度/秒)
        :param omega_r: 右轮角速度 (单位是弧度/秒)
        :param dt: 时间间隔 (单位是秒)
        :param t: 当前时间 (单位是秒)
        """
        # 将角速度转换为线速度
        v_l = omega_l * self.r
        v_r = omega_r * self.r
        
        # 计算线速度和角速度
        v = (v_l + v_r) / 2
        omega = (v_l - v_r) / self.L if v_l != v_r else 0
        
        # 使用Euler方法更新世界坐标位置和方向,速度
        self.x += v * np.cos(self.theta) * dt
        self.y += v * np.sin(self.theta) * dt
        self.theta += omega * dt
        self.vx = v * np.cos(self.theta)
        self.vy = v * np.sin(self.theta)
        self.v = v
        
        # 确保theta在[-pi, pi]范围内
        self.theta = (self.theta + np.pi) % (2 * np.pi) - np.pi
        
        # 记录当前位置到路径
        self.path.append((self.x, self.y))
        
        # 记录当前状态到历史数据
        self.history.append({
            'Time': t,
            'X': self.x,
            'Y': self.y,
            'Theta': self.theta,
            'Vx': self.vx,
            'Vy': self.vy,
            'Omega_L': omega_l,
            'Omega_R': omega_r
        })
        return self.x, self.y

    def plot_path(self):
        """
        绘制机器人的运动轨迹。
        """
        path_x, path_y = zip(*self.path)
        plt.figure(figsize=(8, 8))
        plt.plot(path_x, path_y, marker='o', linestyle='-', color='r')
        plt.title('Differential Drive Robot Path')
        plt.xlabel('X Position (m)')
        plt.ylabel('Y Position (m)')
        plt.grid(True)
        plt.axis('equal')  # 保持比例相同，确保圆不被画成椭圆
        # plt.show()

    def save_history_to_csv(self, filename='robot_motion.csv'):
        """
        将历史运动数据保存为CSV文件param filename: CSV文件名 (默认为'robot_motion.csv')
        """
        df = pd.DataFrame(self.history)
        df.to_csv(filename, index=False)
        print(f"History saved to {filename}")


class PIDController:
    def __init__(self, Kp=0.0, Ki=0.0, Kd=0.0):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.set_point = 0.0
        self.previous_error = 0.0
        self.integral = 0.0

    def update_position(self, res_p, current_p, dt):
        error = res_p- current_p
        self.integral += error * dt
        derivative = (error - self.previous_error) / dt if dt > 0 else 0
        output = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
        self.previous_error = error
        return error, self.integral, derivative
        # return output

    def update_v(self, res_p, current_p, dt):
        error = res_p- current_p
        self.integral += error * dt
        derivative = (error - self.previous_error) / dt if dt > 0 else 0
        output = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
        self.previous_error = error
        return output


    def set_parameters(self, Kp, Ki, Kd):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd

class Robot_Env:
    def __init__(self, robot,idx=1):
        self.action_high= np.array([-25.0, 25.0])
        self.idx=idx
        self.robot = robot
        self.dt01 = 0.1  # 时间步长
        self.dt001 = 0.01
        self.dt02 = 0.2
        # 初始化PID控制器,机器人前进方向x与横向y的PID控制器(用于存储和计算误差,pid计算)
        self.positionPID_x = PIDController(Kp=12, Ki=2.5, Kd=0.1)
        self.positionPID_y = PIDController(Kp=10, Ki=1.0, Kd=0.05)
        self.positions = []
        self.yew_errorlist=[0]
        self.Heading_angle_errorlist=[0]
        self.error_p,self.error_pp=[0],[0]
        self.vrlist=[]
        self.v_p_x, self.v_p_y,self.v_roba=[],[],[]
        self.rob_a, self.angle,self.sd_theta=0, 0, 0
        self.velocities=[]
        self.omega_l, self.omega_r= 0.0, 0.0
        self.dxy=np.array([0,0])
        self.dxylist,self.p_list = [],[]
    def reset(self,robot):
        """重置环境到初始状态"""
        self.__init__(robot,self.idx)
        # self.robot.__init__()
        return np.array([[0.5,0,0],[0,0,0]])

    def calculate_postionError(self, target_position,nebors_position=np.array([0,0,0,0]),neb_theta=np.array([0,0,0,0]),tra_theta=None):
        """计算速度投影方向的位置误差"""# 计算误差 A是智能体连接矩阵，G是智能体与领导者链接向量
        if tra_theta is not None:
            sum_theta = L @ neb_theta 
            self.sd_theta =  G[self.idx-1]*(tra_theta-self.robot.theta)+sum_theta[self.idx-1]#航向角偏差
            non_zero_indices = np.nonzero(A[self.idx-1])[0] # 读取邻居索引
            noberrorx,noberrory,i1 = [],[],0
            for i in non_zero_indices:   
                i1=i1+1
                noberrorx.append(nebors_position[i][0]-self.robot.x )#计算邻居的全局误差
                noberrory.append(nebors_position[i][1]-self.robot.y ) 
            v_robn= np.array([sum(noberrorx), sum(noberrory)]) 
        else:
            v_robn,i1=np.array([0, 0]),0 
        y_last = self.robot.history[-2]['Y']
        x_last = self.robot.history[-2]['X']
        self.v_roba=np.array([self.robot.x-x_last,self.robot.y-y_last])
        v_robp=np.array([target_position[0]-self.robot.x,target_position[1]-self.robot.y])
        if G[self.idx-1]!=0:
            i1=i1+1
        v_robpn = (G[self.idx-1]*v_robp+0*v_robn)/1
        self.dxy = transform_to_local_frame(v_robpn[0], v_robpn[1], self.robot.theta)
        self.dxylist.append(self.dxy)
        v_robpp = np.array([target_position[0]-self.positions[-2][0],target_position[1]-self.positions[-2][1]])
        if np.linalg.norm(self.v_roba) != 0 and np.linalg.norm(v_robpn) != 0 and np.linalg.norm(v_robpp) != 0:
            yaw_error=vector_angle_sign(self.v_roba,v_robpn) #期望偏航角=当前速度方向+与动点p的运动差值角（机器人坐标）
            heading_angle_error=vector_angle_sign(v_robpp,self.v_roba)#航向角的差值（大地坐标）
        else:
            yaw_error=self.yew_errorlist[-1]
            heading_angle_error=self.Heading_angle_errorlist[-1]
        self.yew_errorlist.append(yaw_error)
        self.Heading_angle_errorlist.append(heading_angle_error)
        self.p_list.append(np.array([target_position[0],target_position[1]]))
        # self.error_p.append(np.linalg.norm(target_position-np.array([self.robot.x,self.robot.y])))
        self.error_p.append(np.linalg.norm(v_robpn))
        self.error_pp.append(np.linalg.norm(v_robp))
        self.v_p_x.append(self.error_p[-1]*np.cos(yaw_error))
        self.v_p_y.append(self.error_p[-1]*np.sin(yaw_error))
        rob_v=self.robot.v
        self.vrlist.append(rob_v)
        cur_err_x, integar_err_x, der_err_x = self.positionPID_x.update_position(self.error_p[-1]*np.cos(yaw_error), 0, self.dt02)
        cur_err_y, integar_err_y, der_err_y = self.positionPID_y.update_position(self.error_p[-1]*np.sin(yaw_error), 0, self.dt02)
        errorx,errory,errorp=[cur_err_x, integar_err_x, der_err_x],[cur_err_y, integar_err_y, der_err_y],self.error_p[-1]
        self.angle = math.atan2(v_robpn[1], v_robpn[0])
        return errorx,errory,errorp
    
    def xy_postionError(self, target_position,nebors_position,neb_theta,tra_theta):
        """计算速度投影方向的位置误差"""# 计算误差 A是智能体连接矩阵，G是智能体与领导者链接向量
        sum_theta = L @ neb_theta 
        self.sd_theta =  G[self.idx-1]*(tra_theta-self.robot.theta)+0*sum_theta[self.idx-1]
        non_zero_indices = np.nonzero(A[self.idx-1])[0] # 读取邻居索引
        noberrorx,noberrory = [],[]
        for i in non_zero_indices:   
            noberrorx.append(nebors_position[i][0]-self.robot.x )
            noberrory.append(nebors_position[i][1]-self.robot.y ) 
        v_robn= np.array([sum(noberrorx), sum(noberrory)])  #计算所有邻居智能体的平均相对位置差
        v_robp= np.array([target_position[0]-self.robot.x,target_position[1]-self.robot.y])
        v_robpn = G[self.idx-1]*v_robp+0*v_robn
        self.dxy = transform_to_local_frame(v_robpn[0], v_robpn[1], self.robot.theta)
        self.dxylist.append(self.dxy)
        self.error_p.append(np.linalg.norm(v_robpn))
        self.error_pp.append(np.linalg.norm(v_robp))
        cur_err_x, integar_err_x, der_err_x = self.positionPID_x.update_position(self.dxy[0], 0, self.dt02)
        cur_err_y, integar_err_y, der_err_y = self.positionPID_y.update_position(self.dxy[1], 0, self.dt02)
        errorx,errory,errorp=[cur_err_x, integar_err_x, der_err_x],[cur_err_y, integar_err_y, der_err_y],self.error_p[-1]
        self.angle = math.atan2(v_robpn[1], v_robpn[0])
        return errorx,errory,errorp
    
    def calculate_pid(self, target_position):
        y_last = self.robot.history[-2]['Y']
        x_last = self.robot.history[-2]['X']
        v_roba=np.array([self.robot.x-x_last,self.robot.y-y_last])
        v_robp=np.array([target_position[0]-self.robot.x,target_position[1]-self.robot.y])
        v_robpp = np.array([target_position[0]-self.positions[-2][0],target_position[1]-self.positions[-2][1]])
        if np.linalg.norm(v_roba) != 0 and np.linalg.norm(v_robp) != 0 and np.linalg.norm(v_robpp) != 0:
            yaw_error=vector_angle_sign(v_roba,v_robp) #期望偏航角=当前速度方向+与期望点p的差值角
            heading_angle_error=vector_angle_sign(v_robpp,v_roba)#航向角的差值
        else:
            yaw_error=self.yew_errorlist[-1]
            heading_angle_error=self.Heading_angle_errorlist[-1]
        self.yew_errorlist.append(yaw_error)
        self.Heading_angle_errorlist.append(heading_angle_error)
        self.error_p.append(np.linalg.norm(target_position-np.array([self.robot.x,self.robot.y])))
        self.v_p_x.append(self.error_p[-1]*np.cos(yaw_error))
        self.v_p_y.append(self.error_p[-1]*np.sin(yaw_error))
        rob_v=self.robot.v
        self.vrlist.append(rob_v)
        w_x=self.positionPID_x.update_v(self.error_p[-1]*np.cos(yaw_error), 0, self.dt02)
        w_y=self.positionPID_y.update_v(self.error_p[-1]*np.sin(yaw_error), 0, self.dt02)
        omega_l = w_x-w_y
        omega_r = w_x+w_y
        return np.array([omega_l, omega_r])

    def pid_output(self, error_xy):
        Kp_x, Ki_x, Kd_x, Kp_y, Ki_y, Kd_y, = 20, 2, 0.1, 8, 5, 0.05#20, 2, 0.1, 8, 5, 0.05  #40,3
        ax= Kp_x*error_xy[0][0] + Ki_x*error_xy[0][1] + Kd_x*error_xy[0][2]
        ay= Kp_y*error_xy[1][0] + Ki_y*error_xy[1][1] + Kd_y*error_xy[1][2]
        omega_l = ax + ay
        omega_r = ax - ay
        return np.array([omega_l, omega_r]),ax,ay
    
    def DPID_output(self, error_xy,dpi):
        Kp_x, Ki_x, Kd_x, Kp_y, Ki_y, Kd_y, = 70, 10, 0.1, 10, 1.0, 0.05#12, 2.5, 0.1, 10, 1.0, 0.05
        ax= (Kp_x+dpi[0][0])*error_xy[0][0] + (Ki_x+dpi[0][0])*error_xy[0][1] + Kd_x*error_xy[0][2]
        ay= (Kp_y+dpi[0][0])*error_xy[1][0] + (Ki_y+dpi[0][0])*error_xy[1][1] + Kd_y*error_xy[1][2]
        omega_l = ax + ay
        omega_r = ax - ay
        return np.array([omega_l, omega_r]),ax,ay

    def step(self, target_position,error_PID,action,nebors_position=[0,0,0,0],neb_theta=[0,0,0,0],tra_theta=0):
        """返回新的误差状态、奖励和是否结束"""
        next_state,errorp = self._get_state_error(target_position,nebors_position,neb_theta,tra_theta)#累积误差的计算方式
        reward = self._reward_new06(errorp,error_PID,action)
        done = self._is_done(errorp)
        rob_state = self._get_state()

        return next_state, reward, done, rob_state

    def robot_go(self,action,t):
        omega_l, omega_r = action[0],action[1]
        x,y=self.robot.update(omega_l, omega_r, self.dt001, t)
        return x,y

    def _get_state(self):
        """获取当前状态"""
        return [self.robot.x, self.robot.y, self.robot.theta, 
                self.robot.vx, self.robot.vy, self.robot.L, self.robot.r]
    def _get_state_error(self,target_position,nebors_position,neb_theta,tra_theta):
        """获取当前x和y方向的误差，累积误差，误差变化率"""
        # errorxlist,errorylist,errorp=self.xy_postionError(target_position,nebors_position,neb_theta,tra_theta)
        # errorxlist,errorylist,errorp=self.calculate_postionError(target_position,nebors_position,neb_theta,tra_theta)
        errorxlist,errorylist,errorp=self.calculate_postionError(target_position)#单体
        return np.array([errorxlist,errorylist]),errorp
    
    def _reward_new(self,error,error_pid):
        if abs(error)>0.1:
            if len(self.error_p)>2:
                r_new = 5*(abs(self.error_p[-2])-abs(self.error_p[-1]))#+3*(abs(error_pid)-abs(error))#0.1
            else:
                r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
        else:
            r_new = np.array([4])
        return r_new[0]
    
    def _reward_new01(self,error,error_pid,action):#单体使用
        
        if abs(error)>0.25:
            if np.linalg.norm(action)<10 or abs(action[0]-action[1])>20:
                ra=-10
            else:
                ra=0
            if len(self.error_p)>2:
                r_new = np.array([20*(abs(self.error_p[-2])-abs(self.error_p[-1]))+1.5*math.exp(0.3*math.pi-abs(self.yew_errorlist[-1]))-1.5+0*(abs(error_pid[0])-abs(error))+ra])#0.1
            else:
                r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
        else:
            if len(self.error_p)>2:
                r_new =np.array([1*(abs(self.error_p[-2])-abs(self.error_p[-1]))+10*(abs(self.v_p_y[-2])-abs(self.v_p_y[-1]))
                                  +1*math.exp(0.4*math.pi-abs(self.yew_errorlist[-1]))-1])
            else:
                r_new = np.array([1])
        return r_new[0]
    
    def _reward_new04(self,error,error_pid):
        if abs(error)>0.35:
            if len(self.error_p)>2:
                r_new = np.array([100*(abs(self.error_p[-2])-abs(self.error_p[-1]))])#+0.2*(abs(error_pid)-abs(error))#0.1
            else:
                r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
        else :
            if len(self.error_p)>2:
                r_new = 10*(math.exp(0.5*math.pi-abs(self.yew_errorlist[-1]))-1) + 5*np.array([1*(abs(self.error_p[-2])-abs(self.error_p[-1]))+10*(abs(self.v_p_y[-2])-abs(self.v_p_y[-1]))
                                                                                               +10*(0.35-abs(self.error_p[-1]))])
            else:
                r_new = np.array([1])
        return r_new[0]

    def _reward_new05(self,error,error_pid):
        #multiagent reward
        if abs(error)>0.15:
            if len(self.error_p)>2:
                r_new = np.array([50*(abs(self.error_p[-2])-abs(self.error_p[-1]))])
            else:
                r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
        else :
            if len(self.error_p)>2:
                r_new = 10*(math.exp(0.5*math.pi-abs(self.yew_errorlist[-1]))-1) + 5*np.array([1*(abs(self.error_p[-2])-abs(self.error_p[-1]))+10*(abs(self.v_p_y[-2])-abs(self.v_p_y[-1]))
                                                                                               +10*(0.35-abs(self.error_p[-1]))])
            else:
                r_new = np.array([1])
        return r_new[0]
    
    def _reward_new06(self,error,error_pid,action):#多体使用
        #multiagent reward
        theta = convert_theta(self.robot.theta)
        if abs(self.error_p[-1])>0.3:
            if np.linalg.norm(action)<12 or abs(action[0]-action[1])>25:
                ra=-2
            else:
                ra=0.1
            if len(self.error_p)>2:
                r12= (np.linalg.norm(self.v_roba)-np.linalg.norm(self.p_list[-1]-self.p_list[-2]))*5
                r1=5*(abs(self.error_p[-2])-abs(self.error_p[-1]))+ra+0.1*(abs(error_pid[0])-abs(error))+r12
                r_new = np.array([r1])
            else:
                r_new = np.array([0.5*(math.exp(0.25*math.pi-abs(self.angle-theta))-1)])
        else:
            if len(self.dxylist)>2:
                r1=20*((self.dxylist[-2][0])**2-(self.dxylist[-1][0])**2)+20*((self.dxylist[-2][1])**2-(self.dxylist[-1][1])**2)+0*(math.exp(0.4*math.pi-abs(self.sd_theta))-1) +1*math.exp(0.4*math.pi-abs(self.yew_errorlist[-1]))-1
                # r1=20*(abs(self.error_p[-2])-abs(self.error_p[-1]))+1*math.exp(0.3*math.pi-abs(self.yew_errorlist[-1]))-1
                r_new = np.array([r1])
            else:
                r_new = np.array([0.2])
        return r_new[0]
    
    def _is_done(self,error):
        """判断是否达到终止条件(系统发散)：| error |>"""
        if abs(error)>2.5:
            return True
        else:
            return False


def vector_angle_sign(vector1, vector2):
    # 计算点积
    dot_product = np.dot(vector1, vector2)
    # 计算模长
    norm1 = np.linalg.norm(vector1)
    norm2 = np.linalg.norm(vector2)
    # 计算夹角的余弦值
    cos_theta = dot_product / (norm1 * norm2)
    # 计算夹角（弧度）
    theta = np.arccos(cos_theta)#+0.5*math.pi
    # 将弧度转换为度
    theta_in_degrees = np.degrees(theta)
    cross_product = vector1[0] * vector2[1] - vector1[1] * vector2[0]
    if cross_product > 0:
        return theta  # 向量2在向量1的逆时针方向（左边）
    elif cross_product < 0:
        return -1*theta  # 向量2在向量1的顺时针方向（右边）
    else:
        return 0  # 向量2与向量1共线
    
def d_theta(a,b):
    if abs(a-b)<0.5*math.pi:
        return 0.2
    else:
        return -0.2
    

def plot_trajectory_and_path(x_coords, y_coords, path_x, path_y, path_xPID, path_yPID):
    # 绘制跟踪轨迹图：期望+TD3*4+PID，6条动态线
    fig, ax = plt.subplots(figsize=(8, 8))
    # 设置图形范围
    ax.set_xlim(-1, 3)
    ax.set_ylim(-0.5, 2.5)
    ax.set_aspect('equal')
    ax.grid(True)

    # 初始化线条
    lines = [ax.plot([], [], 'o-', lw=1.5, label='Trajectory')[0]]
    for i in range(4):
        lines.append(ax.plot([], [], 'o-', lw=1, label=f'agent{i+1}')[0])
    lines.append(ax.plot([], [], 'o-', lw=1, label='Path_PID')[0])

    def init():
        for line in lines:
            line.set_data([], [])
        return lines

    def update(frame):
        x1 = x_coords[:frame+1]
        y1 = y_coords[:frame+1]
        lines[0].set_data(x1, y1)
        
        # 按比例增加点数
        x2_frame = (frame + 1) * 10
        y2_frame = (frame + 1) * 10
        for i in range(4):
            x2 = path_x[i][:x2_frame]
            y2 = path_y[i][:y2_frame]
            lines[i+1].set_data(x2, y2)

        # x3 = path_xPID[:x2_frame]
        # y3 = path_yPID[:y2_frame]
        # lines[5].set_data(x3, y3)

        return lines

    ani = FuncAnimation(fig, update, frames=max(len(x_coords), len(path_y[0])), init_func=init, blit=True, interval=200)
    plt.legend(['Trajectory', 'agent1', 'agent2', 'agent3', 'agent4'])
    plt.show()

def rotate_matrix(theta):
    """
    生成旋转矩阵
    :param theta: 旋转角度（弧度）
    """
    return np.array([[np.cos(theta), np.sin(theta)],
                     [-np.sin(theta), np.cos(theta)]])

def transform_to_local_frame(delta_x, delta_y, theta_i):
    """
    将全局坐标系中的点 (x_j, y_j) 转换为智能体i的局部坐标系下的观测值,相对位置
    :param x_i: 智能体i的全局x坐标
    :param y_i: 智能体i的全局y坐标
    :param theta_i: 智能体i的朝向（弧度）
    :param x_j: 邻居智能体j的全局x坐标
    :param y_j: 邻居智能体j的全局y坐标
    :return: 智能体i局部坐标系下的观测值 (x_ji, y_ji)
    """
    # 旋转矩阵
    R = rotate_matrix(theta_i)
    # 转换到局部坐标系
    local_position = R @ np.array([delta_x, delta_y])
    return local_position

def convert_theta(theta):
    theta = math.fmod(theta, 2 * math.pi)
    if theta > math.pi:
        theta = theta - 2 * math.pi
    return theta

def calculate_angle(A, B):
    x1, y1 = A
    x2, y2 = B
    dx = x2 - x1
    dy = y2 - y1
    angle = math.atan2(dy, dx)
    return angle

import numpy as np

def append_columns_to_array(a, b):
    """
    将数组a中的值作为新列追加到数组b的每一行。
    参数:
        a (list of numpy arrays): 包含两个元素的列表，每个元素是一个numpy数组。
        b (numpy array): 二维数组，需要在其右侧追加新列。

    返回:
        numpy array: 扩展后的二维数组，包含原始列和新追加的列。
    """
    # 提取 a 中的值
    a0 = a[0][0]
    a1 = a[1][0]

    # 创建新列，每一行都是 [a0, a1]
    new_columns = np.tile([a0, a1], (b.shape[0], 1))

    # 将新列追加到 b 的右侧
    result = np.hstack((b, new_columns))

    return result

# # 示例调用
# center = (1.5, 1.0)  # 假设中心点坐标
# plot_trajectory_and_path(x_coords, y_coords, path_x, path_y)
#  def _reward_new02(self,error,error_pid):
#         if abs(error)>0.35:
#             if len(self.error_p)>2:
#                 r_new = 5*(abs(self.error_p[-2])-abs(self.error_p[-1]))+0.2*(abs(error_pid)-abs(error))#0.1
#             else:
#                 r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
#         else:
#             if len(self.error_p)>2:
#                 r_new = np.array([1*(abs(self.error_p[-2])-abs(self.error_p[-1]))+5*(abs(self.v_p_y[-2])-abs(self.v_p_y[-1]))
#                                   +1*math.exp(0.9*math.pi-abs(self.yew_errorlist[-1]))-1])
#             else:
#                 r_new = np.array([1])
#         return r_new[0]
    
#     def _reward_new03(self,error,error_pid):
#         if abs(error)>0.3:
#             if len(self.error_p)>2:
#                 r_new = 5*(abs(self.error_p[-2])-abs(self.error_p[-1]))+0.2*(abs(error_pid)-abs(error))#0.1
#             else:
#                 r_new = np.array([0.1])#*(abs(error_pid)-abs(error))
#         else :
#             if len(self.error_p)>2:
#                 r_new = 2*np.array([1*(abs(self.error_p[-2])-abs(self.error_p[-1]))+5.5*(abs(self.v_p_y[-2])-abs(self.v_p_y[-1]))
#                                 +1*math.exp(0.9*math.pi-abs(self.yew_errorlist[-1]))-1])
#                 if abs(error)<0.05:
#                     r_new = r_new+np.array([10*(0.06-abs(error))*math.exp(0.4*math.pi-abs(self.yew_errorlist[-1]))])
#             else:
#                 r_new = np.array([1])
       
#         return r_new[0]
    